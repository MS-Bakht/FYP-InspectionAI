---
title: "Supporting efficient large model training on AMD Instinct GPUs with DeepSpeed"
excerpt: ""
link: https://cloudblogs.microsoft.com/opensource/2022/03/21/supporting-efficient-large-model-training-on-amd-instinct-gpus-with-deepspeed/
date: 2022-03-21 00:00:00
tags: training ZeRO English
---
