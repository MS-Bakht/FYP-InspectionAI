---
title: "DeepSpeed Chat: Easy, Fast and Affordable RLHF Training of ChatGPT-like Models at All Scales"
excerpt: ""
link: https://github.com/microsoft/DeepSpeed/blob/master/blogs/deepspeed-chat/README.md
date: 2023-04-24 00:00:00
tags: training ZeRO RLHF English
---
