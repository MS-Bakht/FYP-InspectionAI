---
title: "DeepSpeed Ulysses: 训练极长序列Transformer模型的系统优化"
excerpt: ""
link: https://github.com/microsoft/DeepSpeed/blob/master/blogs/deepspeed-ulysses/chinese/README.md
date: 2023-08-24 00:00:00
tags: training ZeRO Chinese
---
